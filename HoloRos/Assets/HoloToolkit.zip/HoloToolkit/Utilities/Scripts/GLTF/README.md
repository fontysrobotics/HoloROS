# UnityGLTF
Unity3D library for exporting, loading, parsing, and rendering assets stored in the [glTF 2.0](https://github.com/KhronosGroup/glTF/tree/2.0) file format at runtime.

This snapshot comes from https://github.com/KhronosGroup/UnityGLTF/commit/d75fc63155bcc0108473b8ef169b9ddf123f4d45.